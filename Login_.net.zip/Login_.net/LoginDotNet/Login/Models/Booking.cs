﻿using System;
using System.Collections.Generic;

namespace Login.Models;

public partial class Booking
{
    public int BookingId { get; set; }

    public int? PropertyId { get; set; }

    public DateOnly? BDate { get; set; }

    public DateOnly? StartDate { get; set; }

    public DateOnly? EndDate { get; set; }

    public double? RentPrice { get; set; }

    public double? Deposit { get; set; }

    public int? PayId { get; set; }

    public int? UserId { get; set; }

    public virtual Payment? Pay { get; set; } = null!;

    public virtual Property? Property { get; set; } = null!;

    public virtual User? User { get; set; } = null!;
}
