﻿using System;
using System.Collections.Generic;

namespace Login.Models;

public partial class PropertyAmenity
{
    public int PropertyAmenitiesId { get; set; }

    public int? PropertyId { get; set; }

    public int? AmenitiesId { get; set; }

    public virtual Amenity? Amenities { get; set; }

    public virtual Property? Property { get; set; } = null!;
}
