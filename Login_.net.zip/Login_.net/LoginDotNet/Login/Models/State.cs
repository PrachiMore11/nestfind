﻿using System;
using System.Collections.Generic;

namespace Login.Models;

public partial class State
{
    public int StateId { get; set; }

    public string? StateName { get; set; } = null!;

    public int? StateCode { get; set; }

    public virtual ICollection<City>? Cities { get; set; } = new List<City>();
}
