﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Scaffolding.Internal;

namespace Login.Models;

public partial class NestfindContext : DbContext
{
    public NestfindContext()
    {
    }

    public NestfindContext(DbContextOptions<NestfindContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Amenity> Amenities { get; set; }

    public virtual DbSet<Booking> Bookings { get; set; }

    public virtual DbSet<City> Cities { get; set; }

    public virtual DbSet<Location> Locations { get; set; }

    public virtual DbSet<Payment> Payments { get; set; }

    public virtual DbSet<Photo> Photos { get; set; }

    public virtual DbSet<Property> Properties { get; set; }

    public virtual DbSet<PropertyAmenity> PropertyAmenities { get; set; }

    public virtual DbSet<PropertyType> PropertyTypes { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<State> States { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=localhost;port=3306;user=root;password=More@123;database=nestfind", Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.2.0-mysql"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_0900_ai_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<Amenity>(entity =>
        {
            entity.HasKey(e => e.AmenitiesId).HasName("PRIMARY");

            entity.ToTable("amenities");

            entity.HasIndex(e => e.AmenitiesName, "amenities_name_UNIQUE").IsUnique();

            entity.Property(e => e.AmenitiesId).HasColumnName("amenities_id");
            entity.Property(e => e.AmenitiesName).HasColumnName("amenities_name");
        });

        modelBuilder.Entity<Booking>(entity =>
        {
            entity.HasKey(e => e.BookingId).HasName("PRIMARY");

            entity.ToTable("booking");

            entity.HasIndex(e => e.BookingId, "booking_id_UNIQUE").IsUnique();

            entity.HasIndex(e => e.PayId, "fk_pay_id_idx");

            entity.HasIndex(e => e.PropertyId, "fk_prop_id_idx");

            entity.HasIndex(e => e.UserId, "fk_user_id_idx");

            entity.Property(e => e.BookingId).HasColumnName("booking_id");
            entity.Property(e => e.BDate).HasColumnName("b_date");
            entity.Property(e => e.Deposit).HasColumnName("deposit");
            entity.Property(e => e.EndDate).HasColumnName("end_date");
            entity.Property(e => e.PayId).HasColumnName("pay_id");
            entity.Property(e => e.PropertyId).HasColumnName("property_id");
            entity.Property(e => e.RentPrice).HasColumnName("rent_price");
            entity.Property(e => e.StartDate).HasColumnName("start_date");
            entity.Property(e => e.UserId).HasColumnName("user_id");

            entity.HasOne(d => d.Pay).WithMany(p => p.Bookings)
                .HasForeignKey(d => d.PayId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_pay_id");

            entity.HasOne(d => d.Property).WithMany(p => p.Bookings)
                .HasForeignKey(d => d.PropertyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_prop_id");

            entity.HasOne(d => d.User).WithMany(p => p.Bookings)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_user_id");
        });

        modelBuilder.Entity<City>(entity =>
        {
            entity.HasKey(e => e.CityId).HasName("PRIMARY");

            entity.ToTable("city");

            entity.HasIndex(e => e.StateId, "fk_state_id_idx");

            entity.Property(e => e.CityId).HasColumnName("city_id");
            entity.Property(e => e.CityName)
                .HasMaxLength(255)
                .HasColumnName("city_name");
            entity.Property(e => e.StateId).HasColumnName("state_id");

            entity.HasOne(d => d.State).WithMany(p => p.Cities)
                .HasForeignKey(d => d.StateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_state_id");
        });

        modelBuilder.Entity<Location>(entity =>
        {
            entity.HasKey(e => e.LocationId).HasName("PRIMARY");

            entity.ToTable("location");

            entity.HasIndex(e => e.CityId, "fk_city_id_idx");

            entity.HasIndex(e => e.PropertyId, "property_id_UNIQUE").IsUnique();

            entity.Property(e => e.LocationId).HasColumnName("location_id");
            entity.Property(e => e.Area)
                .HasMaxLength(255)
                .HasColumnName("area");
            entity.Property(e => e.CityId).HasColumnName("city_id");
            entity.Property(e => e.Pincode).HasColumnName("pincode");
            entity.Property(e => e.PropertyId).HasColumnName("property_id");

            entity.HasOne(d => d.City).WithMany(p => p.Locations)
                .HasForeignKey(d => d.CityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_city_id");

            entity.HasOne(d => d.Property).WithOne(p => p.Location)
                .HasForeignKey<Location>(d => d.PropertyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_property_id");
        });

        modelBuilder.Entity<Payment>(entity =>
        {
            entity.HasKey(e => e.PayId).HasName("PRIMARY");

            entity.ToTable("payment");

            entity.Property(e => e.PayId).HasColumnName("pay_id");
            entity.Property(e => e.Amount).HasColumnName("amount");
            entity.Property(e => e.PayDate).HasColumnName("pay_date");
            entity.Property(e => e.PayMode)
                .HasMaxLength(255)
                .HasColumnName("pay_mode");
        });

        modelBuilder.Entity<Photo>(entity =>
        {
            entity.HasKey(e => e.PhotoId).HasName("PRIMARY");

            entity.ToTable("photos");

            entity.HasIndex(e => e.PropertyId, "fk_property_id_idx");

            entity.Property(e => e.PhotoId).HasColumnName("photo_id");
            entity.Property(e => e.Images).HasColumnName("images");
            entity.Property(e => e.PropertyId).HasColumnName("property_id");

            entity.HasOne(d => d.Property).WithMany(p => p.Photos)
                .HasForeignKey(d => d.PropertyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_property_photo_id");
        });

        modelBuilder.Entity<Property>(entity =>
        {
            entity.HasKey(e => e.PropertyId).HasName("PRIMARY");

            entity.ToTable("property");

            entity.HasIndex(e => e.PropertyTypeId, "fk_property_type_id_idx");

            entity.HasIndex(e => e.UserId, "fk_user_id");

            entity.Property(e => e.PropertyId).HasColumnName("property_id");
            entity.Property(e => e.Deposit).HasColumnName("deposit");
            entity.Property(e => e.PropertyTypeId).HasColumnName("property_type_id");
            entity.Property(e => e.RentPrice).HasColumnName("rent_price");
            entity.Property(e => e.UserId).HasColumnName("user_id");

            entity.HasOne(d => d.PropertyType).WithMany(p => p.Properties)
                .HasForeignKey(d => d.PropertyTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_property_type_id");

            entity.HasOne(d => d.User).WithMany(p => p.Properties)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_userid");
        });

        modelBuilder.Entity<PropertyAmenity>(entity =>
        {
            entity.HasKey(e => e.PropertyAmenitiesId).HasName("PRIMARY");

            entity.ToTable("property amenities");

            entity.HasIndex(e => e.AmenitiesId, "fk_amenities_id_idx");

            entity.HasIndex(e => e.PropertyId, "fk_property_id_idx");

            entity.Property(e => e.PropertyAmenitiesId).HasColumnName("property_amenities_id");
            entity.Property(e => e.AmenitiesId).HasColumnName("amenities_id");
            entity.Property(e => e.PropertyId).HasColumnName("property_id");

            entity.HasOne(d => d.Amenities).WithMany(p => p.PropertyAmenities)
                .HasForeignKey(d => d.AmenitiesId)
                .HasConstraintName("fk_amenities_id");

            entity.HasOne(d => d.Property).WithMany(p => p.PropertyAmenities)
                .HasForeignKey(d => d.PropertyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_propertyid");
        });

        modelBuilder.Entity<PropertyType>(entity =>
        {
            entity.HasKey(e => e.PropertyTypeId).HasName("PRIMARY");

            entity.ToTable("property type");

            entity.Property(e => e.PropertyTypeId).HasColumnName("property_type_id");
            entity.Property(e => e.PropertyTypeName)
                .HasMaxLength(255)
                .HasColumnName("property_type_name");
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.RoleId).HasName("PRIMARY");

            entity.ToTable("role");

            entity.Property(e => e.RoleId).HasColumnName("role_id");
            entity.Property(e => e.RoleName)
                .HasMaxLength(50)
                .HasColumnName("role_name");
        });

        modelBuilder.Entity<State>(entity =>
        {
            entity.HasKey(e => e.StateId).HasName("PRIMARY");

            entity.ToTable("state");

            entity.HasIndex(e => e.StateId, "state_id_UNIQUE").IsUnique();

            entity.Property(e => e.StateId).HasColumnName("state_id");
            entity.Property(e => e.StateCode).HasColumnName("state_code");
            entity.Property(e => e.StateName)
                .HasMaxLength(255)
                .HasColumnName("state_name");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PRIMARY");

            entity.ToTable("user");

            entity.HasIndex(e => e.AdharNo, "adhar_no_UNIQUE").IsUnique();

            entity.HasIndex(e => e.Email, "email_UNIQUE").IsUnique();

            entity.HasIndex(e => e.RoleId, "fk_role_id_idx");

            entity.HasIndex(e => e.Mobile, "mobile_UNIQUE").IsUnique();

            entity.HasIndex(e => e.PanNo, "pan_no_UNIQUE").IsUnique();

            entity.HasIndex(e => e.UserName, "user_name_UNIQUE").IsUnique();

            entity.Property(e => e.UserId).HasColumnName("user_id");
            entity.Property(e => e.AdharNo)
                .HasMaxLength(12)
                .HasColumnName("adhar_no");
            entity.Property(e => e.Email).HasColumnName("email");
            entity.Property(e => e.FName)
                .HasMaxLength(255)
                .HasColumnName("f_name");
            entity.Property(e => e.LName)
                .HasMaxLength(255)
                .HasColumnName("l_name");
            entity.Property(e => e.Mobile)
                .HasMaxLength(10)
                .HasColumnName("mobile");
            entity.Property(e => e.PanNo)
                .HasMaxLength(10)
                .HasColumnName("pan_no");
            entity.Property(e => e.Password)
                .HasMaxLength(255)
                .HasColumnName("password");
            entity.Property(e => e.RoleId).HasColumnName("role_id");
            entity.Property(e => e.UserName).HasColumnName("user_name");

            entity.HasOne(d => d.Role).WithMany(p => p.Users)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_role_id");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
