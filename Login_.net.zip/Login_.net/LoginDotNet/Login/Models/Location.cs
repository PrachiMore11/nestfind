﻿using System;
using System.Collections.Generic;

namespace Login.Models;

public partial class Location
{
    public int LocationId { get; set; }

    public int? PropertyId { get; set; }

    public int? CityId { get; set; }

    public string? Area { get; set; }

    public int? Pincode { get; set; }

    public virtual City? City { get; set; } = null!;

    public virtual Property? Property { get; set; } = null!;
}
