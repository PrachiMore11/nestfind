﻿using System;
using System.Collections.Generic;

namespace Login.Models;

public partial class Photo
{
    public int PhotoId { get; set; }

    public int? PropertyId { get; set; }

    public byte[]? Images { get; set; }

    public virtual Property? Property { get; set; } = null!;
}
